import numpy as np
from combos import *

"""
Problem:
A local pizza shop is offering a special deal on a "Surprise Pie," which comes with 3 different toppings,
but the pizza chef gets to choose the toppings.
The pizza shop offers 8 "usual" toppings, like sausage, bacon, pepperoni, peppers, onions, mushrooms, broccoli, and olives.
It also offers 5 "unusual" toppings, like anchovies, shrimp, reindeer, eggs, and potatoes.

What is the probability that the pizza has only "unusual" toppings?
60/1716 == (5/13)*(4/12)*(3/11) == (5*4*3) / (13*12*11)

What is the probability that the pizza has exactly 1 "usual" topping?
?
What is the probability that the pizza has exactly 2 "usual" toppings?
?
What is the probability that the pizza has exactly 3 "usual" toppings?
?
What is the probability that the pizza has at least one "usual" topping?
?
"""