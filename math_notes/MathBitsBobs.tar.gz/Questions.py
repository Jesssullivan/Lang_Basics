import numpy as np
from combos import *

"""
Problem:
A local pizza shop is offering a special deal on a "Surprise Pie," which comes with 3 different toppings,
but the pizza chef gets to choose the toppings.
The pizza shop offers 8 "usual" toppings, like sausage, bacon, pepperoni, peppers, onions, mushrooms, broccoli, and olives.
It also offers 5 "unusual" toppings, like anchovies, shrimp, reindeer, eggs, and potatoes.

What is the probability that the pizza has only "unusual" toppings?
60/1716 == (5/13)*(4/12)*(3/11) == (5*4*3) / (13*12*11)

What is the probability that the pizza has exactly 1 "usual" topping?
?
What is the probability that the pizza has exactly 2 "usual" toppings?
?
What is the probability that the pizza has exactly 3 "usual" toppings?
?
What is the probability that the pizza has at least one "usual" topping?
?
"""

"""
A steroid detection test is 97% effective at detecting steroid use, meaning that the probability of a user testing positive is 0.97. 
Unfortunately, it has a false positive rate of 5%, meaning the the probability of of a nonuser testing positive is 0.05.
A large university estimates that about 6% of its athletes use steroids. 
The universitys quarterback tests positive for steroids, yet he claims he does not use them. What are the chances that he is telling the truth?
?
Suppose that it rains in Spain an average of once every 13 days, and when it does, hurricanes have a 6% chance of happening in Hartford. 
When it does not rain in Spain, hurricanes have a 4% chance of happening in Hartford. What is the probability that it rains in Spain when hurricanes happen in Hartford? 
(Round your answer to four decimal places.)
?
"""